export default function SortBy() {
  return (
    <div className='absolute top-[352px] left-[1162px] text-[12px] font-poppins tracking-[-1%] text-[#B5B7C0] z-[999]'>
      Short by : <span className='font-semibold text-[#000]'>Newest</span>
    </div>
  )
}
